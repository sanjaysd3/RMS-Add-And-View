package com.rms.dao;

import java.util.ArrayList;

import com.rms.bean.Recharge;

public interface IRechDao {

	int addRechargeDetails(Recharge rech);

	ArrayList<Recharge> getAllRechargeInfo();

}
