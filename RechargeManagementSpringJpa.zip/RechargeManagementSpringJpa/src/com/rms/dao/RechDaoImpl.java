package com.rms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rms.bean.Recharge;
@Repository
@Transactional
public class RechDaoImpl implements IRechDao{
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public int addRechargeDetails(Recharge rech) {
		em.persist(rech);
		System.out.println(rech.getRechargeId());
		return rech.getRechargeId();
	}

	@Override
	public ArrayList<Recharge> getAllRechargeInfo() {
		Query qry=em.createNamedQuery("getAllRecharge");
		return (ArrayList<Recharge>) qry.getResultList();
	}

}
