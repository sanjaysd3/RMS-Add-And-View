package com.rms.service;

import java.util.ArrayList;

import com.rms.bean.Recharge;

public interface IRechService {

	int addRechargeDetails(Recharge rech);

	ArrayList<Recharge> getAllRechargeInfo();

}
